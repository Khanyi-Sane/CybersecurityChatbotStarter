﻿using CybersecurityChatbotStarter;

// Program.cs only starts the app and controls the basic flow
var bot = new CyberChatbot("CyberBot");

bot.AskUserName();
bot.Greet();

while (true)
{
    Console.Write($"{bot.UserName}> ");
    string query = Console.ReadLine()?.Trim() ?? string.Empty;

    if (string.IsNullOrWhiteSpace(query))
    {
        Console.WriteLine("Please type something.");
        continue;
    }

    if (query.ToLower() == "exit")
    {
        Console.WriteLine($"Goodbye {bot.UserName}, stay safe online!");
        break;
    }

    string reply = bot.Respond(query);
    if (reply != string.Empty)
        Console.WriteLine($"{bot.BotName}: {reply}  [Topic: {bot.CurrentTopic}]\n");
}