﻿namespace CybersecurityChatbotStarter
{
    /// <summary>
    /// Holds the chatbot's data (properties) and behaviour (methods).
    /// </summary>
    public class CyberChatbot
    {
        // Automatic properties: the compiler creates the hidden backing fields for us
        public string BotName { get; set; }
        public string UserName { get; set; }
        public string CurrentTopic { get; set; }

        // Constructor sets the bot name and a default topic
        public CyberChatbot(string botName)
        {
            BotName = botName;
            UserName = string.Empty;
            CurrentTopic = "General";
        }

        // Keeps asking until the user enters a non-empty name
        public void AskUserName()
        {
            while (string.IsNullOrWhiteSpace(UserName))
            {
                Console.Write("Please enter your name: ");
                UserName = Console.ReadLine()?.Trim() ?? string.Empty;

                if (string.IsNullOrWhiteSpace(UserName))
                    Console.WriteLine("Your name cannot be empty. Please try again.");
            }
        }

        public void Greet()
        {
            Console.WriteLine($"\nHello {UserName}! I'm {BotName}, your cybersecurity assistant.");
            Console.WriteLine("Type 'menu' to see topics or 'exit' to quit.\n");
        }

        // Numbered topic menu
        public void ShowMenu()
        {
            Console.WriteLine("Topics:");
            Console.WriteLine("  1. Password safety");
            Console.WriteLine("  2. Phishing");
            Console.WriteLine("  3. Safe browsing");
        }

        // Decides what to say based on the query and updates CurrentTopic
        public string Respond(string query)
        {
            string q = query.ToLower();

            // TryParse avoids an exception if the input is not a number;
            // it returns false instead, so we can show a clear message.
            if (int.TryParse(q, out int choice))
            {
                switch (choice)
                {
                    case 1: CurrentTopic = "Password safety"; return GetPasswordResponse();
                    case 2: CurrentTopic = "Phishing"; return GetPhishingResponse();
                    case 3: CurrentTopic = "Safe browsing"; return GetSafeBrowsingResponse();
                    default: return "Invalid choice. Please pick a number from 1 to 3.";
                }
            }

            if (q == "menu") { ShowMenu(); return string.Empty; }

            if (q.Contains("password")) { CurrentTopic = "Password safety"; return GetPasswordResponse(); }
            if (q.Contains("phish")) { CurrentTopic = "Phishing"; return GetPhishingResponse(); }
            if (q.Contains("brows")) { CurrentTopic = "Safe browsing"; return GetSafeBrowsingResponse(); }

            if (q.Contains("how are you"))
                return $"I'm running well, {UserName}! Ready to talk cybersecurity.";
            if (q.Contains("purpose"))
                return "My purpose is to teach you basic cybersecurity: passwords, phishing and safe browsing.";

            return "Sorry, I didn't understand that. Try 'password', 'phishing', 'browsing' or type 'menu'.";
        }

        // Response methods, one per topic
        public string GetPasswordResponse() =>
            "Password safety: use long, unique passwords (12+ characters), never reuse them, and enable two-factor authentication.";

        public string GetPhishingResponse() =>
            "Phishing: be suspicious of urgent emails, check the sender's address, and never click unknown links or open unexpected attachments.";

        public string GetSafeBrowsingResponse() =>
            "Safe browsing: look for HTTPS, keep your browser updated, avoid public Wi-Fi for sensitive tasks, and only download from trusted sites.";
    }
}